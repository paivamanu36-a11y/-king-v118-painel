"""Relatório mobile estático e somente leitura, a partir das evidências locais da central V118."""
from pathlib import Path
from datetime import datetime, timezone
from html import escape
import json, re, argparse

ROOT=Path(__file__).resolve().parent
NAMES={'A09':'Auditoria de anúncios e imagens','A17':'Publicidade e campanhas','A19':'Reputação e avaliações','A20':'Custos e margens','A22':'Rastreamento logístico'}
EXPLAIN={'A09':'Consulta anúncios, mas a comparação com cadastro Tray, fotos e referência independente ainda está limitada.', 'A17':'Consulta dados de publicidade; o resultado é uma análise offline, não uma ação sobre campanhas.', 'A19':'Consulta avaliações disponíveis; a cobertura e interpretação ainda exigem validação.', 'A20':'Consulta dados de anúncios e tarifas; faltam custos reais, frete e tributos para comprovar margem.', 'A22':'Consulta pedidos e envios; fiscal atual é estrutural e não certifica a operação logística.'}

def load(path):
    path=path.resolve()
    if not path.is_relative_to(ROOT.resolve()) or path.stat().st_size>4_000_000:raise ValueError('ARQUIVO_FORA_DO_ESCOPO_OU_GRANDE')
    return json.loads(path.read_text(encoding='utf-8'))

def newest(folder, name):
    paths=list((ROOT/folder).glob('GET_*/'+name))
    return max(paths,key=lambda p:p.stat().st_mtime) if paths else None

def s(value,limit=180):
    if value is None:return 'Não informado'
    return escape(str(value)[:limit])

def pill(t):
    t=str(t or 'SEM_DADOS'); css='ok' if t.startswith(('ANALISE_OFFLINE_CONCLUIDA','VALIDO','EXECUTADO_COM_FISCAL')) else 'warn' if any(x in t for x in ('LIMITAC','REVISAO','PENDEN','NAO_HOMOLOGADO')) else 'neutral'
    return f'<span class="pill {css}">{s(t,95)}</span>'

def row(k,v):return f'<div class="datum"><span>{s(k)}</span><strong>{s(v,140)}</strong></div>'

def stamp(iso):
    try:return datetime.fromisoformat(iso.replace('Z','+00:00')).astimezone().strftime('%d/%m/%Y %H:%M:%S')
    except (ValueError,TypeError,AttributeError):return 'Não informado'

def render():
    p=newest('CENTRAL_5_AGENTES','PAINEL_5_AGENTES.json')
    if p is None:raise FileNotFoundError('Execute a central ao menos uma vez antes de gerar o relatório.')
    panel=load(p)
    if panel.get('tipo')!='PAINEL_UNIFICADO_CINCO_AGENTES_GET':raise ValueError('PAINEL_INVALIDO')
    source4=panel.get('agentes',{}).get('A09',{}).get('painel_origem')
    source22=panel.get('agentes',{}).get('A22',{}).get('painel_origem')
    def safe_source(rel):
        if not isinstance(rel,str):return {}
        candidate=(ROOT/rel).resolve()
        if not candidate.is_relative_to(ROOT.resolve()) or candidate.name not in ('PAINEL_ONLINE.json','PAINEL_A22.json'):return {}
        try:return load(candidate)
        except (OSError,ValueError,KeyError):return {}
    data4=safe_source(source4);data22=safe_source(source22)
    sections=[];count=0
    for ag,name in NAMES.items():
        info=panel.get('agentes',{}).get(ag,{})
        entries=(data4.get('agentes',{}).get(ag,{}).get('itens',[]) if ag!='A22' else data22.get('resultados',[]))
        if not isinstance(entries,list):entries=[]
        count+=info.get('registros',0) if isinstance(info.get('registros',0),int) else 0
        details=[]
        if ag=='A17':
            a=data4.get('agentes',{}).get('A17',{})
            if isinstance(a,dict):
                details.append('<div class="record">'+row('Período informado',a.get('periodo','Não informado'))+row('Resultado da coleta',a.get('estado','Não informado'))+'</div>')
        for e in entries[:30]:
            if not isinstance(e,dict):continue
            ident=e.get('item_id') or e.get('order_id') or 'Registro sem identificador'
            body=[f'<div class="record"><h4>{s(ident,70)}</h4>']
            for key,label in [('status_envio','Status do envio'),('substatus_envio','Substatus'),('shipment_id','ID de envio'),('estado','Resultado'),('pendencia','Limitação'),('erro','Erro'),('fiscal','Fiscal'),('retorno_worker','Retorno do worker')]:
                if key in e:body.append(row(label,e[key]))
            if 'codigo_rastreio_presente' in e:body.append(row('Código de rastreio disponível','Sim' if e['codigo_rastreio_presente'] else 'Não'))
            if 'transportadora_presente' in e:body.append(row('Transportadora informada','Sim' if e['transportadora_presente'] else 'Não'))
            body.append('</div>');details.append(''.join(body))
        if not details:details=['<p class="muted">Sem registros detalhados disponíveis nesta evidência. O painel não pode inventar resultados.</p>']
        sections.append(f'''<section class="agent" id="{ag}"><div class="agenttop"><div class="icon">{ag}</div><div><div class="eyebrow">AGENTE / {ag}</div><h2>{s(name)}</h2></div></div><div class="statusline">{pill(info.get('estado'))}<span>{s(info.get('registros',0))} registros</span></div><p class="note">{s(EXPLAIN[ag],400)}</p><details><summary>Ver evidências e resultados <span>+</span></summary><div class="records">{''.join(details)}</div></details></section>''')
    collectors=''.join(f'<div class="collector"><strong>{s(k)}</strong>{row("Código de saída",v.get("retorno"))}{row("Erro",v.get("erro") or "Nenhum reportado")}{row("Bloqueio",v.get("bloqueio") or "Nenhum reportado")}</div>' for k,v in panel.get('coletores',{}).items() if isinstance(v,dict))
    html='''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark"><title>KING V118 | Relatório Executivo Mobile</title><style>
:root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#f4f6f8;background:#090d13}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top right,#1d2d42 0%,#0a1019 46%,#090d13 100%)}main{max-width:760px;margin:auto;padding:18px 16px 56px}.top{padding:28px 4px 24px}.eyebrow{font-size:10px;font-weight:800;letter-spacing:2px;color:#d2a85e;text-transform:uppercase}h1{font-size:clamp(30px,8vw,48px);line-height:1.04;margin:12px 0;letter-spacing:-1.5px}h1 em{font-style:normal;color:#e7ba70}h2{font-size:20px;letter-spacing:-.5px;margin:5px 0}h3{font-size:16px;margin:0 0 14px}p{line-height:1.6}.muted,.note{color:#a7b2c2}.note{font-size:13px}.sub{font-size:13px;color:#a7b2c2}.line{height:1px;background:#28313d;margin:20px 0}.hero{background:linear-gradient(135deg,#1d2a3c,#111a27);border:1px solid #394454;border-radius:18px;padding:18px}.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:15px 0}.stat{padding:14px 10px;background:#131d2a;border:1px solid #2a3545;border-radius:13px}.stat strong{font-size:27px;display:block;color:#f4d19b}.stat span{font-size:10px;color:#aab6c6}.flag{display:inline-block;background:#43331e;color:#ffd99a;border:1px solid #866339;padding:7px 11px;border-radius:30px;font-size:11px;font-weight:800}.agent,.block{background:#111923;border:1px solid #293544;border-radius:17px;margin:12px 0;padding:17px}.agenttop{display:flex;align-items:center;gap:13px}.icon{background:#2c3540;color:#e6b66e;font-weight:900;border:1px solid #62543e;border-radius:13px;padding:12px 9px;font-size:14px}.statusline{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:15px 0;color:#b7c2d0;font-size:12px}.pill{font-size:10px;padding:7px 9px;border-radius:9px;overflow-wrap:anywhere;max-width:75%;font-weight:700}.pill.ok{background:#133b33;color:#88e5bc}.pill.warn{background:#43341f;color:#f1c789}.pill.neutral{background:#29333e;color:#b8c6d6}details{border-top:1px solid #2c3643;margin-top:16px;padding-top:13px}summary{cursor:pointer;color:#e5bc7a;font-size:13px;font-weight:700;display:flex;justify-content:space-between;list-style:none}summary::-webkit-details-marker{display:none}.records{margin-top:13px}.record{padding:12px;border:1px solid #303b4a;border-radius:11px;background:#17212d;margin:8px 0}.record h4{margin:0 0 12px;font-size:13px;color:#e9d0a4;overflow-wrap:anywhere}.datum{display:flex;gap:8px;justify-content:space-between;align-items:flex-start;border-bottom:1px solid #283340;padding:8px 0;font-size:11px}.datum:last-child{border:0}.datum span{color:#a7b2c2;min-width:40%}.datum strong{font-weight:600;text-align:right;overflow-wrap:anywhere}.collector{border:1px solid #303b4a;border-radius:12px;padding:12px;margin:10px 0}.collector>strong{font-size:13px}.footer{font-size:11px;color:#8391a3;margin-top:25px}.nav{display:flex;flex-wrap:wrap;gap:7px;margin:16px 0}.nav a{color:#e4b97a;border:1px solid #3e4856;padding:9px 12px;border-radius:10px;text-decoration:none;font-size:12px}.privacy{border-left:3px solid #d4a45d;padding:10px 13px;background:#1d2430;font-size:12px;color:#c9d2dc;border-radius:0 10px 10px 0}@media(min-width:650px){.agent{padding:22px}.stats{gap:12px}.stat{padding:18px}}
</style></head><body><main><div class="top"><div class="eyebrow">MUNDO ANIMAL SHOP / ML11 / RELATÓRIO EXECUTIVO</div><h1>KING OF THE KINGS <em>V118</em></h1><div class="sub">Central de agentes de IA • Relatório para apresentação no celular</div></div><div class="hero"><span class="flag">PILOTO ONLINE · NÃO HOMOLOGADO</span><h2 style="margin-top:16px">Operação acompanhada por evidências</h2><p class="note">Dados extraídos dos arquivos de execução local. Não significa que os agentes estejam trabalhando continuamente neste instante.</p><div class="stats"><div class="stat"><strong>5</strong><span>Agentes integrados</span></div><div class="stat"><strong>@@COUNT@@</strong><span>Registros no painel</span></div><div class="stat"><strong>2</strong><span>Coletores GET</span></div></div><div class="datum"><span>Última execução registrada</span><strong>@@TIME@@</strong></div><div class="datum"><span>Execução comercial</span><strong>Não autorizada</strong></div><div class="datum"><span>Fiscalização</span><strong>Estrutural / limitada</strong></div></div><div class="nav"><a href="#A09">A09</a><a href="#A17">A17</a><a href="#A19">A19</a><a href="#A20">A20</a><a href="#A22">A22</a><a href="#coleta">Coletores</a></div><h3>Resultados por agente</h3>@@SECTIONS@@<section class="block" id="coleta"><div class="eyebrow">DIAGNÓSTICO</div><h2>Execução dos coletores</h2>@@COLLECTORS@@</section><section class="block"><div class="eyebrow">GOVERNANÇA</div><h2>O que está comprovado?</h2><p class="note">Os cinco agentes foram coordenados na mesma central e existem evidências de consultas GET. Isso não demonstra cobertura integral, cálculos finais, auditoria visual completa ou homologação comercial.</p><div class="privacy">Documento estático para compartilhamento. IDs de pedidos e anúncios podem aparecer; revise antes de encaminhar. Fotos só devem ser adicionadas quando forem evidências reais e verificadas.</div></section><div class="footer">Gerado a partir de arquivos locais do KING V118. Sem credenciais, sem conexão à API e sem atualização automática após o compartilhamento. A07 não acionado.</div></main></body></html>'''
    html=html.replace('@@COUNT@@',str(count)).replace('@@TIME@@',s(stamp(panel.get('gerado_utc')))).replace('@@SECTIONS@@',''.join(sections)).replace('@@COLLECTORS@@',collectors)
    dest=ROOT/'RELATORIO_KING_V118_PARA_MARCOS_CELULAR.html'
    dest.write_text(html,encoding='utf-8')
    print(json.dumps({'arquivo':str(dest),'painel_origem':str(p),'agentes':5,'registros':count,'modo':'ESTATICO_SOMENTE_LEITURA'},ensure_ascii=False))
    return dest

if __name__=='__main__':render()
